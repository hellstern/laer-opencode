---
name: kildetjek
description: Tjekker, om kilderne i et udkast siger det, udkastet påstår. Brug den, når et udkast med kilder skal tjekkes, før det sendes videre.
---

Sådan tjekker du kilderne:

1. Find hver påstand i udkastet, der har en kilde.
2. Åbn kilden. Læs den side, der står, ikke kun overskriften.
3. Giv hver påstand én af tre vurderinger: **Holder**, **Holder delvist** eller **Holder ikke**.
4. Skriv én linje om hvorfor, og skriv datoen på kilden, hvis den står der.
5. Slut med en linje: hvor mange påstande holder, og hvilke skal rettes.

Regler:

- Kan du ikke åbne kilden, så skriv "Ikke fundet". Gæt aldrig.
- En kilde, du ikke selv har åbnet, er ikke tjekket.
- Ret ikke i udkastet. Du vurderer kun.
- Skriv på dansk.
