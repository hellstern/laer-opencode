# Produktkatalog: kontortæpper

Lyngholt Tæpper A/S. Opdigtet virksomhed. Gælder fra 1. oktober 2026.

## Slidklasser

| Slidklasse | Passer til |
| --- | --- |
| 32 | Almindelig kontorbrug, f.eks. kontorer og gange med normal trafik |
| 33 | Kraftig brug, f.eks. mødelokaler, receptioner og kontorlandskaber med meget trafik |

## Lyngholt Kontor Basis

Et prisvenligt tæppe i fliser til almindelige kontorer.

- Slidklasse: 32
- Farver: grå, beige
- Materiale: polyamid

## Lyngholt Kontor Robust

Vores mest solgte tæppe til mødelokaler og andre steder med meget trafik.

- Slidklasse: 33
- Farver: grå, blå, antracit
- Materiale: polyamid med ekstra tæt luv

## Lyngholt Uld Premium

Et tæppe i uld med en blød og eksklusiv overflade. Kræver mere rengøring end polyamid.

- Slidklasse: 33
- Farver: naturhvid, grå
- Materiale: 100 % uld
