# Sådan skriver Lyngholt til kunder

- Skriv på dansk, venligt og kort. Brug "du" og "I", ikke "De".
- Start med at gentage, hvad kunden har bedt om, i én sætning.
- Vis priserne i en tabel.
- Skriv tydeligt, hvis vi ikke kan levere præcis det, kunden har bedt om, og foreslå et alternativ.
- Stil højst tre spørgsmål til kunden, og saml dem til sidst.
- Slut med navnet på den sælger, der har ansvaret, og skriv [Sælgerens navn], indtil en sælger har godkendt tilbuddet.
