# Salgs- og leveringsbetingelser

Lyngholt Tæpper A/S. Opdigtet virksomhed. Gælder fra 1. oktober 2026.

## Priser

- Alle priser i prislisten er i kr. ekskl. moms. Moms er 25 %.
- Tilbud skal vise prisen både ekskl. og inkl. moms.

## Areal og spild

- Ved bestilling lægges 10 % til det areal, der skal dækkes, for spild og tilpasning.
- Spild gælder kun tæppet. Montering og fjernelse beregnes af det areal, der skal dækkes.

## Rabat

- Ved køb af mere end 80 m2 tæppe gives 5 % mængderabat på tæppet.
- Mængderabatten gælder ikke montering, fjernelse eller kørsel.
- Andre rabatter må kun gives af salgschefen. Sælgere og systemer må ikke love andre rabatter.

## Levering og montering

- Varer på lager leveres og monteres 2-3 uger efter, at ordren er bekræftet.
- Varer, der ikke er på lager, kan tidligst leveres 2 uger efter, at de er kommet på lager.
- Montering kræver, at lokalerne er tømt for møbler.
- Fjernelse af gammelt tæppe er ikke med, medmindre kunden beder om det.

## Tilbud

- Et tilbud gælder i 30 dage fra tilbudsdatoen.
- Et tilbud sendes først til kunden, når en sælger har godkendt det.
