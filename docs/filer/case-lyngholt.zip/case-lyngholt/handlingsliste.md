# Handlingsliste, Kommunikation

Lyngholt Tæpper A/S. Opdateret af Jonas 22. oktober 2026.
Alle navne og oplysninger er opdigtede og bruges kun til øvelser.

| Opgave | Ansvarlig | Frist | Status |
| --- | --- | --- | --- |
| Send nyhedsbrev den første tirsdag i måneden | Aisha | Løbende | I gang |
| Vælg design til ny hjemmeside | Mette | 10. oktober 2026 | Færdig |
| Undersøg dato for julefrokost med Salg | Peter | 21. oktober 2026 | Færdig |
| Book lokale til julefrokost fredag 11. december 2026 | Lone | Ikke angivet | Ikke startet |
| Lav plan for LinkedIn-opslag de næste fire uger | Jonas | Ikke angivet | I gang |
| Lav udkast til kundeundersøgelse med højst 8 spørgsmål | Lone | 4. november 2026 | I gang |
