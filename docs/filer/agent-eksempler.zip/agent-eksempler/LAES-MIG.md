# Agent-eksempler til OpenCode

Tre agenter, der arbejder sammen:

| Agent | Type | Må | Opgave |
|---|---|---|---|
| projektleder | primary | skrive filer, starte subagenter | Planlægger og uddelegerer |
| researcher | subagent | hente websider | Finder fakta med kilder |
| redaktoer | subagent | kun læse | Giver feedback på udkast |

Se den fulde opsætningsvejledning for installation og valg af gratis model. Agenterne bruger den model, du har valgt i OpenCode.

## Start

```
cd agent-eksempler
opencode
```

## Prøv denne opgave

> Skriv en kort nyhedsmail til kollegerne om, hvad Microsoft Copilot er, og hvad de skal være opmærksomme på. Brug researcher til fakta og redaktoer til feedback.

## Øvelser

1. Skift `effect: deny` til `effect: allow` for `webfetch` i redaktøren. Bruger den nu nettet?
2. Fjern reglen for `webfetch` i researcher. Hvordan opfører den sig nu?
3. Lav din egen subagent, f.eks. en "oversaetter" eller en "excel-hjaelper".
